-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : hisi
-- 
-- Part : #1
-- Date : 2018-03-30 16:51:57
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `hisi_admin_annex`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_annex`;
CREATE TABLE `hisi_admin_annex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联的数据ID',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '类型',
  `group` varchar(100) NOT NULL DEFAULT 'sys' COMMENT '文件分组',
  `file` varchar(255) NOT NULL COMMENT '上传文件',
  `hash` varchar(64) NOT NULL COMMENT '文件hash值',
  `size` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '附件大小KB',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '使用状态(0未使用，1已使用)',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='[系统] 上传附件';


-- -----------------------------
-- Table structure for `hisi_admin_annex_group`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_annex_group`;
CREATE TABLE `hisi_admin_annex_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '附件分组',
  `count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `size` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '附件大小kb',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='[系统] 附件分组';

-- -----------------------------
-- Records of `hisi_admin_annex_group`
-- -----------------------------
INSERT INTO `hisi_admin_annex_group` VALUES ('1', 'sys', '0', '0.00');

-- -----------------------------
-- Table structure for `hisi_admin_config`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_config`;
CREATE TABLE `hisi_admin_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统配置(1是，0否)',
  `group` varchar(20) NOT NULL DEFAULT 'base' COMMENT '分组',
  `title` varchar(20) NOT NULL COMMENT '配置标题',
  `name` varchar(50) NOT NULL COMMENT '配置名称，由英文字母和下划线组成',
  `value` text NOT NULL COMMENT '配置值',
  `type` varchar(20) NOT NULL DEFAULT 'input' COMMENT '配置类型()',
  `options` text NOT NULL COMMENT '配置项(选项名:选项值)',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '文件上传接口',
  `tips` varchar(255) NOT NULL COMMENT '配置提示',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL COMMENT '状态',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 COMMENT='[系统] 系统配置';

-- -----------------------------
-- Records of `hisi_admin_config`
-- -----------------------------
INSERT INTO `hisi_admin_config` VALUES ('1', '1', 'sys', '扩展配置分组', 'config_group', 'spider:爬虫设置
labeldata:标注设置
dataanalyse:分析设置', 'array', ' ', '', '请按如下格式填写：&lt;br&gt;键值:键名&lt;br&gt;键值:键名&lt;br&gt;&lt;span style=&quot;color:#f00&quot;&gt;键值只能为英文、数字、下划线&lt;/span&gt;', '10', '1', '1492140215', '1492140215');
INSERT INTO `hisi_admin_config` VALUES ('13', '1', 'base', '网站域名', 'site_domain', 'http://localhisi.com', 'input', '', '', '', '2', '1', '1492140215', '1492140215');
INSERT INTO `hisi_admin_config` VALUES ('14', '1', 'upload', '图片上传大小限制', 'upload_image_size', '0', 'input', '', '', '单位：KB，0表示不限制大小', '3', '1', '1490841797', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('15', '1', 'upload', '允许上传图片格式', 'upload_image_ext', 'jpg,png,gif,jpeg,ico', 'input', '', '', '多个格式请用英文逗号（,）隔开', '4', '1', '1490842130', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('16', '1', 'upload', '缩略图裁剪方式', 'thumb_type', '2', 'select', '1:等比例缩放
2:缩放后填充
3:居中裁剪
4:左上角裁剪
5:右下角裁剪
6:固定尺寸缩放
', '', '', '5', '1', '1490842450', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('17', '1', 'upload', '图片水印开关', 'image_watermark', '1', 'switch', '0:关闭
1:开启', '', '', '6', '1', '1490842583', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('18', '1', 'upload', '图片水印图', 'image_watermark_pic', '/upload/sys/image/93/08cd7b08cedda8b4c48f1078318790.png', 'image', '', '', '', '7', '1', '1490842679', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('19', '1', 'upload', '图片水印透明度', 'image_watermark_opacity', '50', 'input', '', '', '可设置值为0~100，数字越小，透明度越高', '8', '1', '1490857704', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('20', '1', 'upload', '图片水印图位置', 'image_watermark_location', '9', 'select', '7:左下角
1:左上角
4:左居中
9:右下角
3:右上角
6:右居中
2:上居中
8:下居中
5:居中', '', '', '9', '1', '1490858228', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('21', '1', 'upload', '文件上传大小限制', 'upload_file_size', '0', 'input', '', '', '单位：KB，0表示不限制大小', '1', '1', '1490859167', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('22', '1', 'upload', '允许上传文件格式', 'upload_file_ext', 'doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip', 'input', '', '', '多个格式请用英文逗号（,）隔开', '2', '1', '1490859246', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('23', '1', 'upload', '文字水印开关', 'text_watermark', '1', 'switch', '0:关闭
1:开启', '', '', '10', '1', '1490860872', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('24', '1', 'upload', '文字水印内容', 'text_watermark_content', '百变魔君 将心独运@izhangxm', 'input', '', '', '', '11', '1', '1490861005', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('25', '1', 'upload', '文字水印字体', 'text_watermark_font', '', 'file', '', '', '不上传将使用系统默认字体', '12', '1', '1490861117', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('26', '1', 'upload', '文字水印字体大小', 'text_watermark_size', '400', 'input', '', '', '单位：px(像素)', '13', '1', '1490861204', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('27', '1', 'upload', '文字水印颜色', 'text_watermark_color', '#000000', 'input', '', '', '文字水印颜色，格式:#000000', '14', '1', '1490861482', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('28', '1', 'upload', '文字水印位置', 'text_watermark_location', '7', 'select', '7:左下角
1:左上角
4:左居中
9:右下角
3:右上角
6:右居中
2:上居中
8:下居中
5:居中', '', '', '11', '1', '1490861718', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('29', '1', 'upload', '缩略图尺寸', 'thumb_size', '300x300;500x500', 'input', '', '', '为空则不生成，生成 500x500 的缩略图，则填写 500x500，多个规格填写参考 300x300;500x500;800x800', '4', '1', '1490947834', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('30', '1', 'develop', '开发模式', 'app_debug', '1', 'switch', '0:关闭
1:开启', '', '', '0', '1', '1491005004', '1492093874');
INSERT INTO `hisi_admin_config` VALUES ('31', '1', 'develop', '页面Trace', 'app_trace', '0', 'switch', '0:关闭
1:开启', '', '', '0', '1', '1491005081', '1492093874');
INSERT INTO `hisi_admin_config` VALUES ('33', '1', 'sys', '富文本编辑器', 'editor', 'ckeditor', 'select', 'ueditor:UEditor
umeditor:UMEditor
kindeditor:KindEditor
ckeditor:CKEditor', '', '', '20', '1', '1491142648', '1492140215');
INSERT INTO `hisi_admin_config` VALUES ('35', '1', 'databases', '备份目录', 'backup_path', './backup/database/', 'input', '', '', '数据库备份路径,路径必须以 / 结尾', '0', '1', '1491881854', '1491965974');
INSERT INTO `hisi_admin_config` VALUES ('36', '1', 'databases', '备份分卷大小', 'part_size', '20971520', 'input', '', '', '用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '0', '1', '1491881975', '1491965974');
INSERT INTO `hisi_admin_config` VALUES ('37', '1', 'databases', '备份压缩开关', 'compress', '1', 'switch', '0:关闭
1:开启', '', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '0', '1', '1491882038', '1491965974');
INSERT INTO `hisi_admin_config` VALUES ('38', '1', 'databases', '备份压缩级别', 'compress_level', '4', 'radio', '1:最低
4:一般
9:最高', '', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '0', '1', '1491882154', '1491965974');
INSERT INTO `hisi_admin_config` VALUES ('39', '1', 'base', '网站状态', 'site_status', '1', 'switch', '0:关闭
1:开启', '', '站点关闭后将不能访问，后台可正常登录', '1', '1', '1492049460', '1494690024');
INSERT INTO `hisi_admin_config` VALUES ('40', '1', 'sys', '后台管理路径', 'admin_path', 'admin.php', 'input', '', '', '必须以.php为后缀', '5', '1', '1492139196', '1492140215');
INSERT INTO `hisi_admin_config` VALUES ('41', '1', 'base', '网站标题', 'site_title', '中粮数据分析', 'input', '', '', '网站标题是体现一个网站的主旨，要做到主题突出、标题简洁、连贯等特点，建议不超过28个字', '6', '1', '1492502354', '1494695131');
INSERT INTO `hisi_admin_config` VALUES ('42', '1', 'base', '网站关键词', 'site_keywords', 'hisiphp,hisiphp框架,php开源框架', 'input', '', '', '网页内容所包含的核心搜索关键词，多个关键字请用英文逗号&quot;,&quot;分隔', '7', '1', '1494690508', '1494690780');
INSERT INTO `hisi_admin_config` VALUES ('43', '1', 'base', '网站描述', 'site_description', '', 'textarea', '', '', '网页的描述信息，搜索引擎采纳后，作为搜索结果中的页面摘要显示，建议不超过80个字', '8', '1', '1494690669', '1494691075');
INSERT INTO `hisi_admin_config` VALUES ('44', '1', 'base', 'ICP备案信息', 'site_icp', '', 'input', '', '', '请填写ICP备案号，用于展示在网站底部，ICP备案官网：&lt;a href=&quot;http://www.miibeian.gov.cn&quot; target=&quot;_blank&quot;&gt;http://www.miibeian.gov.cn&lt;/a&gt;', '9', '1', '1494691721', '1494692046');
INSERT INTO `hisi_admin_config` VALUES ('45', '1', 'base', '站点统计代码', 'site_statis', '', 'textarea', '', '', '第三方流量统计代码，前台调用时请先用 htmlspecialchars_decode函数转义输出', '10', '1', '1494691959', '1494694797');
INSERT INTO `hisi_admin_config` VALUES ('46', '1', 'base', '网站名称', 'site_name', '中粮数据分析', 'input', '', '', '将显示在浏览器窗口标题等位置', '3', '1', '1494692103', '1494694680');
INSERT INTO `hisi_admin_config` VALUES ('47', '1', 'base', '网站LOGO', 'site_logo', '', 'image', '', '', '网站LOGO图片', '4', '1', '1494692345', '1494693235');
INSERT INTO `hisi_admin_config` VALUES ('48', '1', 'base', '网站图标', 'site_favicon', '', 'image', '', '/admin/annex/favicon', '又叫网站收藏夹图标，它显示位于浏览器的地址栏或者标题前面，&lt;strong class=&quot;red&quot;&gt;.ico格式&lt;/strong&gt;，&lt;a href=&quot;https://www.baidu.com/s?ie=UTF-8&amp;wd=favicon&quot; target=&quot;_blank&quot;&gt;点此了解网站图标&lt;/a&gt;', '5', '1', '1494692781', '1494693966');
INSERT INTO `hisi_admin_config` VALUES ('49', '1', 'base', '手机网站', 'wap_site_status', '0', 'switch', '0:关闭
1:开启', '', '如果有手机网站，请设置为开启状态，否则只显示PC网站', '2', '1', '1498405436', '1498405436');
INSERT INTO `hisi_admin_config` VALUES ('50', '1', 'sys', '云端推送', 'cloud_push', '0', 'switch', '0:关闭
1:开启', '', '关闭之后，无法通过云端推送安装扩展', '30', '1', '1504250320', '1504250320');
INSERT INTO `hisi_admin_config` VALUES ('51', '0', 'base', '手机网站域名', 'wap_domain', '中粮数据分析', 'input', '', '', '手机访问将自动跳转至此域名', '2', '1', '1504304776', '1504304837');
INSERT INTO `hisi_admin_config` VALUES ('52', '0', 'sys', '多语言支持', 'multi_language', '0', 'switch', '0:关闭
1:开启', '', '开启后你可以自由上传多种语言包', '40', '1', '1506532211', '1506532211');
INSERT INTO `hisi_admin_config` VALUES ('59', '0', 'spider', '爬虫管理说明', 'spider_welcome_info', '&lt;p&gt;&lt;span style=&quot;font-size:22px&quot;&gt;&lt;span style=&quot;background-color:#2ecc71&quot;&gt;&lt;span style=&quot;color:#ffffff&quot;&gt;请到系统设置中的爬虫设置选项卡设置本说明&lt;/span&gt;，&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;span style=&quot;font-size:22px&quot;&gt;&lt;span style=&quot;background-color:#2ecc71&quot;&gt;本说明由&lt;span style=&quot;color:#c0392b&quot;&gt;富文本编辑器&lt;/span&gt;生成，支持复杂样式描述。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;', 'multi_textarea', '', '', '', '0', '1', '1522336126', '1522336126');
INSERT INTO `hisi_admin_config` VALUES ('60', '0', 'spider', '爬虫列表', 'spider_list', '\'pubmed\':PUBMED爬虫', 'array', '', '', '', '0', '1', '1522383247', '1522383247');
INSERT INTO `hisi_admin_config` VALUES ('61', '0', 'labeldata', '标注说明', 'label_welcome_info', '&lt;p&gt;&lt;span style=&quot;font-size:24px&quot;&gt;请到系统设置中的&lt;span style=&quot;color:#ffffff&quot;&gt;&lt;span style=&quot;background-color:#c0392b&quot;&gt;标注设置&lt;/span&gt;&lt;/span&gt;选项卡设置本说明，&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;span style=&quot;font-size:24px&quot;&gt;本说明由富文本编辑器生成，支持复杂样式描述。&lt;/span&gt;&lt;/p&gt;', 'multi_textarea', '', '', '', '0', '1', '1522386794', '1522387669');
INSERT INTO `hisi_admin_config` VALUES ('62', '0', 'dataanalyse', '使用说明', 'dataanalyse_welcome_info', '&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;请到系统设置中的&lt;span style=&quot;color:#ffffff&quot;&gt;&lt;span style=&quot;background-color:#c0392b&quot;&gt;分析设置&lt;/span&gt;&lt;/span&gt;选项卡设置本说明，&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;本说明由富文本编辑器生成，支持复杂样式描述。&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;/upload/sys/image/bd/2cee4a4f8dfbe7d4d3810ed60a3c2c.JPG&quot; style=&quot;height:221px; width:224px&quot; /&gt;&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&amp;nbsp;&lt;/p&gt;

&lt;p&gt;&amp;nbsp;&lt;/p&gt;

&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/upload/sys/image/50/abc1c1bf2d9f21fb88894e60fb219b.JPG&quot; style=&quot;height:183px; width:419px&quot; /&gt;&lt;/p&gt;

&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/upload/sys/image/47/fbe148f4542c1a4d40e9464354125d.png&quot; style=&quot;height:195px; width:334px&quot; /&gt;&lt;/p&gt;

&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/upload/sys/image/47/fbe148f4542c1a4d40e9464354125d.png&quot; style=&quot;height:136px; width:234px&quot; /&gt;&lt;/p&gt;', 'multi_textarea', '', '', '', '0', '1', '1522387319', '1522387910');
INSERT INTO `hisi_admin_config` VALUES ('63', '0', 'sys', '首页欢迎', 'sys_welcome_info', '&lt;div style=&quot;border-bottom:solid #b4a38a 1.0pt; padding:0cm 0cm 11.0pt 0cm&quot;&gt;
&lt;p style=&quot;text-align:left&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;span style=&quot;font-size:22.5pt&quot;&gt;&lt;span style=&quot;color:#b4a38a&quot;&gt;关于中粮&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;
&lt;/div&gt;

&lt;p&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;span style=&quot;font-size:15.0pt&quot;&gt;&lt;span style=&quot;color:#b4a38a&quot;&gt;中粮集团有限公司（COFCO）是立足中国的国际大粮商，是全球布局、全产业链、拥有最大市场和发展潜力的农业及粮油食品企业，集贸易、加工、销售、研发于一体的投资控股公司。中粮集团以&amp;ldquo;确保国家粮食安全，把中国人的饭碗牢牢端在自己手中&amp;rdquo;为己任，致力于打造具有全球竞争力的世界一流大粮商，担当服务国家宏观调控、维护国家粮食和食品安全，构建具有中粮特色的国有资本投资公司。&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&amp;nbsp;&lt;/p&gt;

&lt;p&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;span style=&quot;font-size:12.0pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;作为与新中国同龄的国有企业，中粮集团历经六十余年发展，在中国市场上占据领先优势，业务遍及全球140多个国家和地区，以粮、油、糖、棉为核心主业，覆盖稻谷、小麦、玉米、油脂油料、糖、棉花等农作物品种以及生物能源，同时涉及食品、金融、地产行业。&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;span style=&quot;font-size:12.0pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;目前，中粮集团资产总额5373.6亿元，年营业收入4426.5亿元，年经营总量近1.6亿吨，全球仓储能力3100万吨，年加工能力9000万吨，年港口中转能力6500万吨。&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;span style=&quot;font-size:12.0pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;在中国，中粮集团综合加工能力超过6000万吨，是中国最大的农产品加工企业，涵盖了中国人日常消费的主要农产品品类，包括稻谷、小麦、玉米、油脂油料、糖、棉花、肉制品、乳制品、酒、茶叶等。形成了包括种植养殖、仓储、物流、贸易、加工、分销等环节的上下游一体化网络，搭建起 &amp;ldquo;北粮南运&amp;ldquo;的大动脉。在维护中国粮油市场稳定中，发挥着重要的支撑作用。&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;span style=&quot;font-size:12.0pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;在全球，中粮集团形成了覆盖全球主要粮油产区、销区的粮油设施布局，拥有包括种植、采购、仓储、物流和港口在内的全球生产采购平台和贸易网络，在南美、黑海等全球粮食主产区和亚洲新兴市场间建立起稳定的粮食走廊，集团50%以上营业收入来自于海外业务。为统筹利用国际国内两种资源、两个市场，稳定中国市场供应、保障粮食安全打下坚实基础。&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;span style=&quot;font-size:12.0pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;在做强做优做大粮、油、糖、棉核心业务同时，中粮集团建立了食品、金融和地产三大主营业务。在食品领域，作为优质产品的生产者，优质品牌的创造者，业务涵盖奶制品、肉食、酒、茶叶、食品包装，拥有福临门、蒙牛、长城、中茶等具有影响力的品牌，230万家终端售点遍布中国952个大中城市、十几万个县乡村，将世界四分之一以上人口的餐桌与全世界的农场紧密地联系在一起。创造性地为农业发展提供金融服务，已经形成信托、期货交易代理、保险、风险管理咨询、银行、基金等金融业务链。同时也是卓越生活空间的建设者，建设商业地产、住宅地产、酒店、旅游地产以及区域综合开发。&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;span style=&quot;font-size:12.0pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;作为国有资本投资公司改革试点企业，中粮集团积极推进企业体制机制改革，构建中国农粮食品领域的国有资本投资平台、资源整合平台和海外投资平台，不断聚焦核心主业，推进专业化经营，形成了以核心产品为主线的十八个专业化公司。&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;span style=&quot;font-size:12.0pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;作为投资控股企业，中粮集团旗下拥有13家上市公司，其中包括中国食品（00506.HK）、中粮控股（00606.HK）、蒙牛乳业（02319.HK）、中粮包装（00906.HK）、大悦城地产（00207.HK）、中粮肉食（01610.HK）、福田实业（00420.HK）、雅士利国际（01230.HK）、现代牧业（01117.HK）九家香港上市公司，以及中粮糖业（600737.SH）、酒鬼酒（000799.SZ）、中粮地产（000031.SZ）、中粮生化（000930.SZ）四家内地公司。&lt;br /&gt;
&lt;br /&gt;
在十九大精神指引下，中粮集团瞄准世界一流企业，大力弘扬&amp;ldquo;忠于国计，良于民生&amp;rdquo;的战略使命、&amp;ldquo;严、实、廉&amp;rdquo;的工作作风、&amp;ldquo;品牌、品质、品格&amp;rdquo;的企业经营理念，聚焦事关国家粮食安全、食品安全的粮油食品领域，通过主业、品牌、资本三大拉动，全面实现四个转型：从恢复性增长转变为聚焦主业的常态发展，从传统国有企业经营模式转变为投资公司的专业化经营，从国内政策市经营转变为完全市场化的国际国内两个市场经营，从传统农贸企业转变为新型生产服务经营主体。&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;span style=&quot;font-size:12.0pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;&amp;ldquo;十三五&amp;rdquo;期间，中粮集团在农粮食品领域国有资本占比将提高到80%以上，实现&amp;ldquo;321155&amp;rdquo;经营目标，即年经营玉米3000万吨、年加工2000万吨大豆、1000万吨水稻、1000万吨小麦，年经营食糖500万吨，国外一手粮源5000万吨。更好地发挥在国家宏观调控中的主力军作用，切实提升国家粮食安全保障能力，服务农业供给侧结构性改革，在新时代谱写中国特色社会主义新篇章，为实现 &amp;ldquo;两个一百年&amp;rdquo;奋斗目标的宏伟蓝图做出贡献。&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;

&lt;p&gt;&amp;nbsp;&lt;/p&gt;

&lt;p&gt;&amp;nbsp;&lt;/p&gt;

&lt;p&gt;&amp;nbsp;&lt;/p&gt;

&lt;p&gt;&amp;nbsp;&lt;/p&gt;', 'multi_textarea', '', '', '', '0', '1', '1522389117', '1522389117');

-- -----------------------------
-- Table structure for `hisi_admin_hook`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_hook`;
CREATE TABLE `hisi_admin_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '系统插件',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `source` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子来源[plugins.插件名，module.模块名]',
  `intro` varchar(200) NOT NULL DEFAULT '' COMMENT '钩子简介',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 钩子表';

-- -----------------------------
-- Records of `hisi_admin_hook`
-- -----------------------------
INSERT INTO `hisi_admin_hook` VALUES ('1', '1', 'system_admin_index', '', '后台首页', '1', '1490885108', '1490885108');
INSERT INTO `hisi_admin_hook` VALUES ('2', '1', 'system_admin_tips', '', '后台所有页面提示', '1', '1490885108', '1490885108');
INSERT INTO `hisi_admin_hook` VALUES ('3', '1', 'system_annex_upload', '', '附件上传钩子，可扩展上传到第三方存储', '1', '1490885108', '1490885108');
INSERT INTO `hisi_admin_hook` VALUES ('4', '1', 'system_member_login', '', '会员登陆成功之后的动作', '1', '1490885108', '1490885108');
INSERT INTO `hisi_admin_hook` VALUES ('5', '1', 'system_member_register', '', '会员注册成功后的动作', '1', '1490885108', '1490885108');

-- -----------------------------
-- Table structure for `hisi_admin_hook_plugins`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_hook_plugins`;
CREATE TABLE `hisi_admin_hook_plugins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(32) NOT NULL COMMENT '钩子id',
  `plugins` varchar(32) NOT NULL COMMENT '插件标识',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) unsigned NOT NULL DEFAULT '0',
  `sort` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 钩子-插件对应表';

-- -----------------------------
-- Records of `hisi_admin_hook_plugins`
-- -----------------------------
INSERT INTO `hisi_admin_hook_plugins` VALUES ('1', 'system_admin_index', 'hisiphp', '1510063011', '1510063011', '0', '1');

-- -----------------------------
-- Table structure for `hisi_admin_language`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_language`;
CREATE TABLE `hisi_admin_language` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '语言包名称',
  `code` varchar(20) NOT NULL DEFAULT '' COMMENT '编码',
  `locale` varchar(255) NOT NULL DEFAULT '' COMMENT '本地浏览器语言编码',
  `icon` varchar(30) NOT NULL DEFAULT '' COMMENT '图标',
  `pack` varchar(100) NOT NULL DEFAULT '' COMMENT '上传的语言包',
  `sort` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='[系统] 语言包';

-- -----------------------------
-- Records of `hisi_admin_language`
-- -----------------------------
INSERT INTO `hisi_admin_language` VALUES ('1', '简体中文', 'zh-cn', 'zh-CN,zh-CN.UTF-8,zh-cn', '', '1', '1', '1');

-- -----------------------------
-- Table structure for `hisi_admin_log`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_log`;
CREATE TABLE `hisi_admin_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) DEFAULT '',
  `url` varchar(200) DEFAULT '',
  `param` text,
  `remark` varchar(255) DEFAULT '',
  `count` int(10) unsigned NOT NULL DEFAULT '1',
  `ip` varchar(128) DEFAULT '',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=577 DEFAULT CHARSET=utf8 COMMENT='[系统] 操作日志';

-- -----------------------------
-- Records of `hisi_admin_log`
-- -----------------------------
INSERT INTO `hisi_admin_log` VALUES ('514', '1', '系统日志', 'admin/log/index', '[]', '浏览数据', '1', '0.0.0.0', '1522394451', '1522394451');
INSERT INTO `hisi_admin_log` VALUES ('515', '1', '钩子管理', 'admin/hook/index', '[]', '浏览数据', '4', '0.0.0.0', '1522394640', '1522395386');
INSERT INTO `hisi_admin_log` VALUES ('516', '1', '修改钩子', 'admin/hook/edit', '{\"id\":\"1\"}', '浏览数据', '1', '0.0.0.0', '1522394650', '1522394650');
INSERT INTO `hisi_admin_log` VALUES ('517', '1', '修改钩子', 'admin/hook/edit', '{\"id\":\"2\"}', '浏览数据', '1', '0.0.0.0', '1522394665', '1522394665');
INSERT INTO `hisi_admin_log` VALUES ('518', '1', '在线升级', 'admin/upgrade/index', '[]', '浏览数据', '2', '0.0.0.0', '1522394708', '1522395385');
INSERT INTO `hisi_admin_log` VALUES ('519', '1', '插件管理', 'admin/plugins/index', '[]', '浏览数据', '4', '0.0.0.0', '1522394733', '1522395387');
INSERT INTO `hisi_admin_log` VALUES ('520', '1', '插件配置', 'admin/plugins/setting', '{\"id\":\"1\"}', '浏览数据', '1', '0.0.0.0', '1522394740', '1522394740');
INSERT INTO `hisi_admin_log` VALUES ('521', '1', '插件配置', 'admin/plugins/setting', '{\"id\":\"__ADMIN_CSS__\"}', '浏览数据', '1', '0.0.0.0', '1522394740', '1522394740');
INSERT INTO `hisi_admin_log` VALUES ('522', '1', '插件管理', 'admin/plugins/index', '{\"status\":\"1\"}', '浏览数据', '2', '0.0.0.0', '1522394758', '1522394761');
INSERT INTO `hisi_admin_log` VALUES ('523', '1', '插件管理', 'admin/plugins/index', '{\"status\":\"0\"}', '浏览数据', '2', '0.0.0.0', '1522394759', '1522394761');
INSERT INTO `hisi_admin_log` VALUES ('524', '1', '导入插件', 'admin/plugins/import', '[]', '浏览数据', '1', '0.0.0.0', '1522394764', '1522394764');
INSERT INTO `hisi_admin_log` VALUES ('525', '1', '设计插件', 'admin/plugins/design', '[]', '浏览数据', '2', '0.0.0.0', '1522394765', '1522394769');
INSERT INTO `hisi_admin_log` VALUES ('526', '1', '使用必读', 'cofco/spider/index', '[]', '浏览数据', '5', '0.0.0.0', '1522394870', '1522399908');
INSERT INTO `hisi_admin_log` VALUES ('527', '1', '爬虫列表', 'cofco/spider/spider_list', '[]', '浏览数据', '1', '0.0.0.0', '1522394871', '1522394871');
INSERT INTO `hisi_admin_log` VALUES ('528', '1', '使用必读', 'cofco/labeldata/index', '[]', '浏览数据', '13', '0.0.0.0', '1522394873', '1522399427');
INSERT INTO `hisi_admin_log` VALUES ('529', '1', '模块管理', 'admin/module/index', '[]', '浏览数据', '2', '0.0.0.0', '1522395010', '1522395388');
INSERT INTO `hisi_admin_log` VALUES ('530', '1', '模块管理', 'admin/module/index', '{\"status\":\"1\"}', '浏览数据', '1', '0.0.0.0', '1522395011', '1522395011');
INSERT INTO `hisi_admin_log` VALUES ('531', '1', '模块管理', 'admin/module/index', '{\"status\":\"0\"}', '浏览数据', '1', '0.0.0.0', '1522395012', '1522395012');
INSERT INTO `hisi_admin_log` VALUES ('532', '1', '系统设置', 'admin/system/index', '[]', '浏览数据', '11', '0.0.0.0', '1522395389', '1522399903');
INSERT INTO `hisi_admin_log` VALUES ('533', '1', '系统配置', 'admin/system/index', '{\"group\":\"sys\"}', '浏览数据', '2', '0.0.0.0', '1522395392', '1522396389');
INSERT INTO `hisi_admin_log` VALUES ('534', '1', '基础配置', 'admin/system/index', '{\"group\":\"base\"}', '浏览数据', '1', '0.0.0.0', '1522395397', '1522395397');
INSERT INTO `hisi_admin_log` VALUES ('535', '1', '配置管理', 'admin/config/index', '[]', '浏览数据', '7', '0.0.0.0', '1522395399', '1522399904');
INSERT INTO `hisi_admin_log` VALUES ('536', '1', '系统设置', 'admin/system/index', '{\"group\":\"labeldata\"}', '浏览数据', '6', '0.0.0.0', '1522395401', '1522396089');
INSERT INTO `hisi_admin_log` VALUES ('537', '1', '系统设置', 'admin/system/index', '{\"group\":\"spider\"}', '浏览数据', '15', '0.0.0.0', '1522395402', '1522397041');
INSERT INTO `hisi_admin_log` VALUES ('538', '1', '系统设置', 'admin/system/index', '{\"group\":\"dataanalyse\"}', '浏览数据', '11', '0.0.0.0', '1522395406', '1522396561');
INSERT INTO `hisi_admin_log` VALUES ('539', '1', '数据库配置', 'admin/system/index', '{\"group\":\"databases\"}', '浏览数据', '4', '0.0.0.0', '1522395407', '1522396568');
INSERT INTO `hisi_admin_log` VALUES ('540', '1', '后台首页', 'admin/index/index', '[]', '浏览数据', '15', '0.0.0.0', '1522395418', '1522399708');
INSERT INTO `hisi_admin_log` VALUES ('541', '1', '系统菜单', 'admin/menu/index', '[]', '浏览数据', '10', '0.0.0.0', '1522395459', '1522399903');
INSERT INTO `hisi_admin_log` VALUES ('542', '1', '删除菜单', 'admin/menu/del', '{\"ids\":\"3\"}', '浏览数据', '2', '0.0.0.0', '1522395483', '1522395508');
INSERT INTO `hisi_admin_log` VALUES ('543', '1', '修改菜单', 'admin/menu/edit', '{\"id\":\"5\"}', '浏览数据', '1', '0.0.0.0', '1522395491', '1522395491');
INSERT INTO `hisi_admin_log` VALUES ('544', '1', '删除菜单', 'admin/menu/del', '{\"ids\":\"5\"}', '浏览数据', '1', '0.0.0.0', '1522395501', '1522395501');
INSERT INTO `hisi_admin_log` VALUES ('545', '1', '删除菜单', 'admin/menu/del', '{\"ids\":\"__ADMIN_CSS__\"}', '浏览数据', '1', '0.0.0.0', '1522395502', '1522395502');
INSERT INTO `hisi_admin_log` VALUES ('546', '1', '修改菜单', 'admin/menu/edit', '{\"id\":\"4\"}', '浏览数据', '1', '0.0.0.0', '1522395547', '1522395547');
INSERT INTO `hisi_admin_log` VALUES ('547', '1', '修改菜单', 'admin/menu/edit', '{\"module\":\"admin\",\"pid\":\"2\",\"title\":\"\\u5feb\\u901f\\u5f00\\u59cb\",\"icon\":\"aicon ai-caidan\",\"url\":\"admin\\/quick\",\"param\":\"\",\"status\":\"1\",\"system\":\"1\",\"nav\":\"1\",\"id\":\"4\"}', '保存数据', '1', '0.0.0.0', '1522395565', '1522395565');
INSERT INTO `hisi_admin_log` VALUES ('548', '1', '系统信息', 'admin/index/sysinfo', '[]', '浏览数据', '6', '0.0.0.0', '1522395576', '1522399707');
INSERT INTO `hisi_admin_log` VALUES ('549', '1', '删除菜单', 'admin/menu/del', '{\"ids\":\"1\"}', '浏览数据', '1', '0.0.0.0', '1522395587', '1522395587');
INSERT INTO `hisi_admin_log` VALUES ('550', '1', '配置管理', 'admin/config/index', '{\"group\":\"sys\"}', '浏览数据', '1', '0.0.0.0', '1522396050', '1522396050');
INSERT INTO `hisi_admin_log` VALUES ('551', '1', '配置管理', 'admin/config/index', '{\"group\":\"base\"}', '浏览数据', '1', '0.0.0.0', '1522396053', '1522396053');
INSERT INTO `hisi_admin_log` VALUES ('552', '1', '上传配置', 'admin/system/index', '{\"group\":\"upload\"}', '浏览数据', '8', '0.0.0.0', '1522396066', '1522396502');
INSERT INTO `hisi_admin_log` VALUES ('553', '1', '开发配置', 'admin/system/index', '{\"group\":\"develop\"}', '浏览数据', '2', '0.0.0.0', '1522396067', '1522396101');
INSERT INTO `hisi_admin_log` VALUES ('554', '1', '附件上传', 'admin/annex/upload', '{\"thumb\":\"no\",\"water\":\"no\"}', '保存数据', '1', '0.0.0.0', '1522396114', '1522396114');
INSERT INTO `hisi_admin_log` VALUES ('555', '1', '上传配置', 'admin/system/index', '{\"id\":{\"upload_file_size\":\"0\",\"upload_file_ext\":\"doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip\",\"upload_image_size\":\"0\",\"upload_image_ext\":\"jpg,png,gif,jpeg,ico\",\"thumb_size\":\"300x300;500x500\",\"thumb_type\":\"2\",\"image_watermark\":\"1\",\"image_watermark_pic\":\"\\/upload\\/sys\\/image\\/93\\/08cd7b08cedda8b4c48f1078318790.png\",\"image_watermark_opacity\":\"50\",\"image_watermark_location\":\"9\",\"text_watermark_content\":\"\\u767e\\u53d8\\u9b54\\u541b \\u5c06\\u5fc3\\u72ec\\u8fd0@izhangxm\",\"text_watermark_location\":\"9\",\"text_watermark_font\":\"\",\"text_watermark_size\":\"40\",\"text_watermark_color\":\"#000000\"},\"type\":{\"upload_file_size\":\"input\",\"upload_file_ext\":\"input\",\"upload_image_size\":\"input\",\"upload_image_ext\":\"input\",\"thumb_size\":\"input\",\"thumb_type\":\"select\",\"image_watermark\":\"switch\",\"image_watermark_pic\":\"image\",\"image_watermark_opacity\":\"input\",\"image_watermark_location\":\"select\",\"text_watermark\":\"switch\",\"text_watermark_content\":\"input\",\"text_watermark_location\":\"select\",\"text_watermark_font\":\"file\",\"text_watermark_size\":\"input\",\"text_watermark_color\":\"input\"},\"group\":\"upload\"}', '保存数据', '1', '0.0.0.0', '1522396126', '1522396126');
INSERT INTO `hisi_admin_log` VALUES ('556', '1', '附件上传', 'admin/annex/upload', '{\"CKEditor\":\"id_dataanalyse_welcome_info\",\"CKEditorFuncNum\":\"1\",\"langCode\":\"zh-cn\",\"ckCsrfToken\":\"omJ907I6WPd88hkG6Ik18zUCJw1mPhPCYr5dzbHU\",\"thumb\":\"no\",\"from\":\"ckeditor\"}', '保存数据', '6', '0.0.0.0', '1522396153', '1522396516');
INSERT INTO `hisi_admin_log` VALUES ('557', '1', '系统设置', 'admin/system/index', '{\"id\":{\"dataanalyse_welcome_info\":\"&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;\\u8bf7\\u5230\\u7cfb\\u7edf\\u8bbe\\u7f6e\\u4e2d\\u7684&lt;span style=&quot;color:#ffffff&quot;&gt;&lt;span style=&quot;background-color:#c0392b&quot;&gt;\\u5206\\u6790\\u8bbe\\u7f6e&lt;\\/span&gt;&lt;\\/span&gt;\\u9009\\u9879\\u5361\\u8bbe\\u7f6e\\u672c\\u8bf4\\u660e\\uff0c&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;\\u672c\\u8bf4\\u660e\\u7531\\u5bcc\\u6587\\u672c\\u7f16\\u8f91\\u5668\\u751f\\u6210\\uff0c\\u652f\\u6301\\u590d\\u6742\\u6837\\u5f0f\\u63cf\\u8ff0\\u3002&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/bd\\/2cee4a4f8dfbe7d4d3810ed60a3c2c.JPG&quot; style=&quot;height:221px; width:224px&quot; \\/&gt;&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&amp;nbsp;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/fd\\/034a37602155cd71d7771f5fd64e27.JPG&quot; style=&quot;height:179px; width:128px&quot; \\/&gt;&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&amp;nbsp;&lt;\\/p&gt;\"},\"type\":{\"dataanalyse_welcome_info\":\"multi_textarea\"},\"group\":\"dataanalyse\"}', '保存数据', '1', '0.0.0.0', '1522396211', '1522396211');
INSERT INTO `hisi_admin_log` VALUES ('558', '1', '使用必读', 'cofco/dataanalyse/index', '[]', '浏览数据', '6', '0.0.0.0', '1522396214', '1522399183');
INSERT INTO `hisi_admin_log` VALUES ('559', '1', '系统设置', 'admin/system/index', '{\"id\":{\"dataanalyse_welcome_info\":\"&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;\\u8bf7\\u5230\\u7cfb\\u7edf\\u8bbe\\u7f6e\\u4e2d\\u7684&lt;span style=&quot;color:#ffffff&quot;&gt;&lt;span style=&quot;background-color:#c0392b&quot;&gt;\\u5206\\u6790\\u8bbe\\u7f6e&lt;\\/span&gt;&lt;\\/span&gt;\\u9009\\u9879\\u5361\\u8bbe\\u7f6e\\u672c\\u8bf4\\u660e\\uff0c&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;\\u672c\\u8bf4\\u660e\\u7531\\u5bcc\\u6587\\u672c\\u7f16\\u8f91\\u5668\\u751f\\u6210\\uff0c\\u652f\\u6301\\u590d\\u6742\\u6837\\u5f0f\\u63cf\\u8ff0\\u3002&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/bd\\/2cee4a4f8dfbe7d4d3810ed60a3c2c.JPG&quot; style=&quot;height:221px; width:224px&quot; \\/&gt;&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&amp;nbsp;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&amp;nbsp;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/50\\/abc1c1bf2d9f21fb88894e60fb219b.JPG&quot; style=&quot;height:183px; width:419px&quot; \\/&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&amp;nbsp;&lt;\\/p&gt;\"},\"type\":{\"dataanalyse_welcome_info\":\"multi_textarea\"},\"group\":\"dataanalyse\"}', '保存数据', '1', '0.0.0.0', '1522396285', '1522396285');
INSERT INTO `hisi_admin_log` VALUES ('560', '1', '系统设置', 'admin/system/index', '{\"id\":{\"dataanalyse_welcome_info\":\"&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;\\u8bf7\\u5230\\u7cfb\\u7edf\\u8bbe\\u7f6e\\u4e2d\\u7684&lt;span style=&quot;color:#ffffff&quot;&gt;&lt;span style=&quot;background-color:#c0392b&quot;&gt;\\u5206\\u6790\\u8bbe\\u7f6e&lt;\\/span&gt;&lt;\\/span&gt;\\u9009\\u9879\\u5361\\u8bbe\\u7f6e\\u672c\\u8bf4\\u660e\\uff0c&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;\\u672c\\u8bf4\\u660e\\u7531\\u5bcc\\u6587\\u672c\\u7f16\\u8f91\\u5668\\u751f\\u6210\\uff0c\\u652f\\u6301\\u590d\\u6742\\u6837\\u5f0f\\u63cf\\u8ff0\\u3002&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/bd\\/2cee4a4f8dfbe7d4d3810ed60a3c2c.JPG&quot; style=&quot;height:221px; width:224px&quot; \\/&gt;&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&amp;nbsp;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&amp;nbsp;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/50\\/abc1c1bf2d9f21fb88894e60fb219b.JPG&quot; style=&quot;height:183px; width:419px&quot; \\/&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/47\\/fbe148f4542c1a4d40e9464354125d.png&quot; style=&quot;height:195px; width:334px&quot; \\/&gt;&lt;\\/p&gt;\"},\"type\":{\"dataanalyse_welcome_info\":\"multi_textarea\"},\"group\":\"dataanalyse\"}', '保存数据', '1', '0.0.0.0', '1522396367', '1522396367');
INSERT INTO `hisi_admin_log` VALUES ('561', '1', '上传配置', 'admin/system/index', '{\"id\":{\"upload_file_size\":\"0\",\"upload_file_ext\":\"doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip\",\"upload_image_size\":\"0\",\"upload_image_ext\":\"jpg,png,gif,jpeg,ico\",\"thumb_size\":\"300x300;500x500\",\"thumb_type\":\"2\",\"image_watermark\":\"1\",\"image_watermark_pic\":\"\\/upload\\/sys\\/image\\/93\\/08cd7b08cedda8b4c48f1078318790.png\",\"image_watermark_opacity\":\"50\",\"image_watermark_location\":\"9\",\"text_watermark\":\"1\",\"text_watermark_content\":\"\\u767e\\u53d8\\u9b54\\u541b \\u5c06\\u5fc3\\u72ec\\u8fd0@izhangxm\",\"text_watermark_location\":\"9\",\"text_watermark_font\":\"\",\"text_watermark_size\":\"40\",\"text_watermark_color\":\"#000000\"},\"type\":{\"upload_file_size\":\"input\",\"upload_file_ext\":\"input\",\"upload_image_size\":\"input\",\"upload_image_ext\":\"input\",\"thumb_size\":\"input\",\"thumb_type\":\"select\",\"image_watermark\":\"switch\",\"image_watermark_pic\":\"image\",\"image_watermark_opacity\":\"input\",\"image_watermark_location\":\"select\",\"text_watermark\":\"switch\",\"text_watermark_content\":\"input\",\"text_watermark_location\":\"select\",\"text_watermark_font\":\"file\",\"text_watermark_size\":\"input\",\"text_watermark_color\":\"input\"},\"group\":\"upload\"}', '保存数据', '1', '0.0.0.0', '1522396394', '1522396394');
INSERT INTO `hisi_admin_log` VALUES ('562', '1', '上传配置', 'admin/system/index', '{\"id\":{\"upload_file_size\":\"0\",\"upload_file_ext\":\"doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip\",\"upload_image_size\":\"0\",\"upload_image_ext\":\"jpg,png,gif,jpeg,ico\",\"thumb_size\":\"300x300;500x500\",\"thumb_type\":\"2\",\"image_watermark\":\"1\",\"image_watermark_pic\":\"\\/upload\\/sys\\/image\\/93\\/08cd7b08cedda8b4c48f1078318790.png\",\"image_watermark_opacity\":\"50\",\"image_watermark_location\":\"9\",\"text_watermark\":\"1\",\"text_watermark_content\":\"\\u767e\\u53d8\\u9b54\\u541b \\u5c06\\u5fc3\\u72ec\\u8fd0@izhangxm\",\"text_watermark_location\":\"7\",\"text_watermark_font\":\"\",\"text_watermark_size\":\"40\",\"text_watermark_color\":\"#000000\"},\"type\":{\"upload_file_size\":\"input\",\"upload_file_ext\":\"input\",\"upload_image_size\":\"input\",\"upload_image_ext\":\"input\",\"thumb_size\":\"input\",\"thumb_type\":\"select\",\"image_watermark\":\"switch\",\"image_watermark_pic\":\"image\",\"image_watermark_opacity\":\"input\",\"image_watermark_location\":\"select\",\"text_watermark\":\"switch\",\"text_watermark_content\":\"input\",\"text_watermark_location\":\"select\",\"text_watermark_font\":\"file\",\"text_watermark_size\":\"input\",\"text_watermark_color\":\"input\"},\"group\":\"upload\"}', '保存数据', '1', '0.0.0.0', '1522396413', '1522396413');
INSERT INTO `hisi_admin_log` VALUES ('563', '1', '系统设置', 'admin/system/index', '{\"id\":{\"dataanalyse_welcome_info\":\"&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;\\u8bf7\\u5230\\u7cfb\\u7edf\\u8bbe\\u7f6e\\u4e2d\\u7684&lt;span style=&quot;color:#ffffff&quot;&gt;&lt;span style=&quot;background-color:#c0392b&quot;&gt;\\u5206\\u6790\\u8bbe\\u7f6e&lt;\\/span&gt;&lt;\\/span&gt;\\u9009\\u9879\\u5361\\u8bbe\\u7f6e\\u672c\\u8bf4\\u660e\\uff0c&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;\\u672c\\u8bf4\\u660e\\u7531\\u5bcc\\u6587\\u672c\\u7f16\\u8f91\\u5668\\u751f\\u6210\\uff0c\\u652f\\u6301\\u590d\\u6742\\u6837\\u5f0f\\u63cf\\u8ff0\\u3002&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/bd\\/2cee4a4f8dfbe7d4d3810ed60a3c2c.JPG&quot; style=&quot;height:221px; width:224px&quot; \\/&gt;&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&amp;nbsp;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&amp;nbsp;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/50\\/abc1c1bf2d9f21fb88894e60fb219b.JPG&quot; style=&quot;height:183px; width:419px&quot; \\/&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/47\\/fbe148f4542c1a4d40e9464354125d.png&quot; style=&quot;height:195px; width:334px&quot; \\/&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&amp;nbsp;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/47\\/fbe148f4542c1a4d40e9464354125d.png&quot; style=&quot;height:195px; width:334px&quot; \\/&gt;&lt;\\/p&gt;\"},\"type\":{\"dataanalyse_welcome_info\":\"multi_textarea\"},\"group\":\"dataanalyse\"}', '保存数据', '1', '0.0.0.0', '1522396462', '1522396462');
INSERT INTO `hisi_admin_log` VALUES ('564', '1', '上传配置', 'admin/system/index', '{\"id\":{\"upload_file_size\":\"0\",\"upload_file_ext\":\"doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip\",\"upload_image_size\":\"0\",\"upload_image_ext\":\"jpg,png,gif,jpeg,ico\",\"thumb_size\":\"300x300;500x500\",\"thumb_type\":\"2\",\"image_watermark\":\"1\",\"image_watermark_pic\":\"\\/upload\\/sys\\/image\\/93\\/08cd7b08cedda8b4c48f1078318790.png\",\"image_watermark_opacity\":\"50\",\"image_watermark_location\":\"9\",\"text_watermark\":\"1\",\"text_watermark_content\":\"\\u767e\\u53d8\\u9b54\\u541b \\u5c06\\u5fc3\\u72ec\\u8fd0@izhangxm\",\"text_watermark_location\":\"7\",\"text_watermark_font\":\"\",\"text_watermark_size\":\"400\",\"text_watermark_color\":\"#000000\"},\"type\":{\"upload_file_size\":\"input\",\"upload_file_ext\":\"input\",\"upload_image_size\":\"input\",\"upload_image_ext\":\"input\",\"thumb_size\":\"input\",\"thumb_type\":\"select\",\"image_watermark\":\"switch\",\"image_watermark_pic\":\"image\",\"image_watermark_opacity\":\"input\",\"image_watermark_location\":\"select\",\"text_watermark\":\"switch\",\"text_watermark_content\":\"input\",\"text_watermark_location\":\"select\",\"text_watermark_font\":\"file\",\"text_watermark_size\":\"input\",\"text_watermark_color\":\"input\"},\"group\":\"upload\"}', '保存数据', '1', '0.0.0.0', '1522396497', '1522396497');
INSERT INTO `hisi_admin_log` VALUES ('565', '1', '系统设置', 'admin/system/index', '{\"id\":{\"dataanalyse_welcome_info\":\"&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;\\u8bf7\\u5230\\u7cfb\\u7edf\\u8bbe\\u7f6e\\u4e2d\\u7684&lt;span style=&quot;color:#ffffff&quot;&gt;&lt;span style=&quot;background-color:#c0392b&quot;&gt;\\u5206\\u6790\\u8bbe\\u7f6e&lt;\\/span&gt;&lt;\\/span&gt;\\u9009\\u9879\\u5361\\u8bbe\\u7f6e\\u672c\\u8bf4\\u660e\\uff0c&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;\\u672c\\u8bf4\\u660e\\u7531\\u5bcc\\u6587\\u672c\\u7f16\\u8f91\\u5668\\u751f\\u6210\\uff0c\\u652f\\u6301\\u590d\\u6742\\u6837\\u5f0f\\u63cf\\u8ff0\\u3002&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:26px&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/bd\\/2cee4a4f8dfbe7d4d3810ed60a3c2c.JPG&quot; style=&quot;height:221px; width:224px&quot; \\/&gt;&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&amp;nbsp;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&amp;nbsp;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/50\\/abc1c1bf2d9f21fb88894e60fb219b.JPG&quot; style=&quot;height:183px; width:419px&quot; \\/&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/47\\/fbe148f4542c1a4d40e9464354125d.png&quot; style=&quot;height:195px; width:334px&quot; \\/&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;\\/upload\\/sys\\/image\\/47\\/fbe148f4542c1a4d40e9464354125d.png&quot; style=&quot;height:136px; width:234px&quot; \\/&gt;&lt;\\/p&gt;\"},\"type\":{\"dataanalyse_welcome_info\":\"multi_textarea\"},\"group\":\"dataanalyse\"}', '保存数据', '2', '0.0.0.0', '1522396537', '1522396556');
INSERT INTO `hisi_admin_log` VALUES ('566', '1', '系统设置', 'admin/system/index', '{\"id\":{\"spider_welcome_info\":\"&lt;p&gt;&lt;span style=&quot;font-size:22px&quot;&gt;&lt;span style=&quot;background-color:#2ecc71&quot;&gt;&lt;span style=&quot;color:#ffffff&quot;&gt;\\u8bf7\\u5230\\u7cfb\\u7edf\\u8bbe\\u7f6e\\u4e2d\\u7684\\u722c\\u866b\\u8bbe\\u7f6e\\u9009\\u9879\\u5361\\u8bbe\\u7f6e\\u672c\\u8bf4\\u660e&lt;\\/span&gt;\\uff0c&lt;\\/span&gt;&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:22px&quot;&gt;&lt;span style=&quot;background-color:#2ecc71&quot;&gt;\\u672c\\u8bf4\\u660e\\u7531&lt;span style=&quot;color:#c0392b&quot;&gt;\\u5bcc\\u6587\\u672c\\u7f16\\u8f91\\u5668&lt;\\/span&gt;\\u751f\\u6210\\uff0c\\u652f\\u6301\\u590d\\u6742\\u6837\\u5f0f\\u63cf\\u8ff0\\u3002&lt;\\/span&gt;&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;ol&gt;\\r\\n\\t&lt;li&gt;&lt;span style=&quot;font-size:22px&quot;&gt;&lt;span style=&quot;background-color:#2ecc71&quot;&gt;ad&lt;\\/span&gt;&lt;\\/span&gt;&lt;\\/li&gt;\\r\\n&lt;\\/ol&gt;\",\"spider_list\":\"\'pubmed\':PUBMED\\u722c\\u866b\"},\"type\":{\"spider_welcome_info\":\"multi_textarea\",\"spider_list\":\"array\"},\"group\":\"spider\"}', '保存数据', '1', '0.0.0.0', '1522397022', '1522397022');
INSERT INTO `hisi_admin_log` VALUES ('567', '1', '系统设置', 'admin/system/index', '{\"id\":{\"spider_welcome_info\":\"&lt;p&gt;&lt;span style=&quot;font-size:22px&quot;&gt;&lt;span style=&quot;background-color:#2ecc71&quot;&gt;&lt;span style=&quot;color:#ffffff&quot;&gt;\\u8bf7\\u5230\\u7cfb\\u7edf\\u8bbe\\u7f6e\\u4e2d\\u7684\\u722c\\u866b\\u8bbe\\u7f6e\\u9009\\u9879\\u5361\\u8bbe\\u7f6e\\u672c\\u8bf4\\u660e&lt;\\/span&gt;\\uff0c&lt;\\/span&gt;&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;span style=&quot;font-size:22px&quot;&gt;&lt;span style=&quot;background-color:#2ecc71&quot;&gt;\\u672c\\u8bf4\\u660e\\u7531&lt;span style=&quot;color:#c0392b&quot;&gt;\\u5bcc\\u6587\\u672c\\u7f16\\u8f91\\u5668&lt;\\/span&gt;\\u751f\\u6210\\uff0c\\u652f\\u6301\\u590d\\u6742\\u6837\\u5f0f\\u63cf\\u8ff0\\u3002&lt;\\/span&gt;&lt;\\/span&gt;&lt;\\/p&gt;\",\"spider_list\":\"\'pubmed\':PUBMED\\u722c\\u866b\"},\"type\":{\"spider_welcome_info\":\"multi_textarea\",\"spider_list\":\"array\"},\"group\":\"spider\"}', '保存数据', '1', '0.0.0.0', '1522397038', '1522397038');
INSERT INTO `hisi_admin_log` VALUES ('568', '1', '关键词列表', 'cofco/spider/keywords_list', '[]', '浏览数据', '2', '0.0.0.0', '1522399338', '1522399907');
INSERT INTO `hisi_admin_log` VALUES ('569', '1', '系统管理员', 'admin/user/index', '[]', '浏览数据', '1', '0.0.0.0', '1522399433', '1522399433');
INSERT INTO `hisi_admin_log` VALUES ('570', '1', '[示例]列表模板', 'admin/develop/lists', '[]', '浏览数据', '2', '0.0.0.0', '1522399569', '1522399701');
INSERT INTO `hisi_admin_log` VALUES ('571', '1', '[示例]编辑模板', 'admin/develop/edit', '[]', '浏览数据', '1', '0.0.0.0', '1522399622', '1522399622');
INSERT INTO `hisi_admin_log` VALUES ('572', '1', '附件上传', 'admin/annex/upload', '{\"action\":\"config\",\"noCache\":\"1522399622807\",\"thumb\":\"no\",\"from\":\"ueditor\"}', '浏览数据', '1', '0.0.0.0', '1522399623', '1522399623');
INSERT INTO `hisi_admin_log` VALUES ('573', '1', '附件上传', 'admin/annex/upload', '{\"action\":\"config\",\"noCache\":\"1522399622805\",\"thumb\":\"no\",\"from\":\"ueditor\"}', '浏览数据', '1', '0.0.0.0', '1522399623', '1522399623');
INSERT INTO `hisi_admin_log` VALUES ('574', '1', '[弹窗]会员选择', 'admin/member/pop', '{\"callback\":\"func\"}', '浏览数据', '2', '0.0.0.0', '1522399662', '1522399669');
INSERT INTO `hisi_admin_log` VALUES ('575', '1', '数据库管理', 'admin/database/index', '[]', '浏览数据', '1', '0.0.0.0', '1522399915', '1522399915');
INSERT INTO `hisi_admin_log` VALUES ('576', '1', '备份数据库', 'admin/database/export', '{\"ids\":[\"hisi_admin_annex\",\"hisi_admin_annex_group\",\"hisi_admin_config\",\"hisi_admin_hook\",\"hisi_admin_hook_plugins\",\"hisi_admin_language\",\"hisi_admin_log\",\"hisi_admin_member\",\"hisi_admin_member_level\",\"hisi_admin_menu\",\"hisi_admin_menu_lang\",\"hisi_admin_module\",\"hisi_admin_plugins\",\"hisi_admin_role\",\"hisi_admin_user\"]}', '保存数据', '1', '0.0.0.0', '1522399917', '1522399917');

-- -----------------------------
-- Table structure for `hisi_admin_member`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_member`;
CREATE TABLE `hisi_admin_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员等级ID',
  `nick` varchar(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `username` varchar(30) NOT NULL DEFAULT '' COMMENT '用户名',
  `mobile` bigint(11) unsigned NOT NULL DEFAULT '0' COMMENT '手机号',
  `email` varchar(50) NOT NULL DEFAULT '' COMMENT '邮箱',
  `password` varchar(128) NOT NULL COMMENT '密码',
  `money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '可用金额',
  `frozen_money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '冻结金额',
  `income` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '收入统计',
  `expend` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '开支统计',
  `exper` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '经验值',
  `integral` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '积分',
  `frozen_integral` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '冻结积分',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '性别(1男，0女)',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '头像',
  `last_login_ip` varchar(128) NOT NULL DEFAULT '' COMMENT '最后登陆IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登陆时间',
  `login_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登陆次数',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '到期时间(0永久)',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态(0禁用，1正常)',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1000001 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 会员表';

-- -----------------------------
-- Records of `hisi_admin_member`
-- -----------------------------
INSERT INTO `hisi_admin_member` VALUES ('1000000', '1', '123456', 'test', '0', '', '$2y$10$RqIjt7IIJW1hFrHG9zk.zeeFhZbNPYL/wq1wmDGIY0cV2DDWMDwyC', '0.00', '0.00', '0.00', '0.00', '0', '0', '0', '1', '', '', '0', '0', '0', '1', '1493274686');

-- -----------------------------
-- Table structure for `hisi_admin_member_level`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_member_level`;
CREATE TABLE `hisi_admin_member_level` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL COMMENT '等级名称',
  `min_exper` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最小经验值',
  `max_exper` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最大经验值',
  `discount` int(2) unsigned NOT NULL DEFAULT '100' COMMENT '折扣率(%)',
  `intro` varchar(255) NOT NULL COMMENT '等级简介',
  `default` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '默认等级',
  `expire` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员有效期(天)',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='[系统] 会员等级';

-- -----------------------------
-- Records of `hisi_admin_member_level`
-- -----------------------------
INSERT INTO `hisi_admin_member_level` VALUES ('1', '注册会员', '0', '0', '100', '', '1', '0', '1', '0', '1491966814');

-- -----------------------------
-- Table structure for `hisi_admin_menu`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_menu`;
CREATE TABLE `hisi_admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '管理员ID(快捷菜单专用)',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `module` varchar(20) NOT NULL COMMENT '模块名或插件名，插件名格式:plugins.插件名',
  `title` varchar(20) NOT NULL COMMENT '菜单标题',
  `icon` varchar(80) NOT NULL DEFAULT 'aicon ai-shezhi' COMMENT '菜单图标',
  `url` varchar(200) NOT NULL COMMENT '链接地址(模块/控制器/方法)',
  `param` varchar(200) NOT NULL DEFAULT '' COMMENT '扩展参数',
  `target` varchar(20) NOT NULL DEFAULT '_self' COMMENT '打开方式(_blank,_self)',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `debug` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '开发模式可见',
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统菜单，系统菜单不可删除',
  `nav` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否为菜单显示，1显示0不显示',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态1显示，0隐藏',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 管理菜单';

-- -----------------------------
-- Records of `hisi_admin_menu`
-- -----------------------------
INSERT INTO `hisi_admin_menu` VALUES ('2', '0', '0', 'admin', '系统', '', 'admin/system', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('4', '0', '2', 'admin', '快速开始', 'aicon ai-caidan', 'admin/quick', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('6', '0', '2', 'admin', '系统功能', 'aicon ai-gongneng', 'admin/system', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('7', '0', '2', 'admin', '会员管理', 'aicon ai-huiyuanliebiao', 'admin/member', '', '_self', '20', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('8', '0', '2', 'admin', '系统扩展', 'aicon ai-shezhi', 'admin/extend', '', '_self', '30', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('9', '0', '2', 'admin', '开发专用', 'aicon ai-doubleleft', 'admin/develop', '', '_self', '40', '1', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('10', '0', '6', 'admin', '系统设置', 'aicon ai-icon01', 'admin/system/index', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('11', '0', '6', 'admin', '配置管理', 'aicon ai-peizhiguanli', 'admin/config/index', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('12', '0', '6', 'admin', '系统菜单', 'aicon ai-systemmenu', 'admin/menu/index', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('13', '0', '6', 'admin', '管理员角色', '', 'admin/user/role', '', '_self', '4', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('14', '0', '6', 'admin', '系统管理员', 'aicon ai-tubiao05', 'admin/user/index', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('15', '0', '6', 'admin', '系统日志', 'aicon ai-xitongrizhi-tiaoshi', 'admin/log/index', '', '_self', '6', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('16', '0', '6', 'admin', '附件管理', '', 'admin/annex/index', '', '_self', '7', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('17', '0', '8', 'admin', '模块管理', 'aicon ai-mokuaiguanli1', 'admin/module/index', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('18', '0', '8', 'admin', '插件管理', 'aicon ai-chajianguanli', 'admin/plugins/index', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('19', '0', '8', 'admin', '钩子管理', 'aicon ai-icon-test', 'admin/hook/index', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('20', '0', '7', 'admin', '会员等级', 'aicon ai-huiyuandengji', 'admin/member/level', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('21', '0', '7', 'admin', '会员列表', 'aicon ai-huiyuanliebiao', 'admin/member/index', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('22', '0', '9', 'admin', '[示例]列表模板', '', 'admin/develop/lists', '', '_self', '1', '1', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('23', '0', '9', 'admin', '[示例]编辑模板', '', 'admin/develop/edit', '', '_self', '2', '1', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('24', '0', '4', 'admin', '后台首页', 'aicon ai-shouye', 'admin/index/index', '', '_self', '100', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('25', '0', '4', 'admin', '清空缓存', '', 'admin/index/clear', '', '_self', '2', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('26', '0', '12', 'admin', '添加菜单', '', 'admin/menu/add', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('27', '0', '12', 'admin', '修改菜单', '', 'admin/menu/edit', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('28', '0', '12', 'admin', '删除菜单', '', 'admin/menu/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('29', '0', '12', 'admin', '状态设置', '', 'admin/menu/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('30', '0', '12', 'admin', '排序设置', '', 'admin/menu/sort', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('31', '0', '12', 'admin', '添加快捷菜单', '', 'admin/menu/quick', '', '_self', '6', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('32', '0', '12', 'admin', '导出菜单', '', 'admin/menu/export', '', '_self', '7', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('33', '0', '13', 'admin', '添加角色', '', 'admin/user/addrole', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('34', '0', '13', 'admin', '修改角色', '', 'admin/user/editrole', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('35', '0', '13', 'admin', '删除角色', '', 'admin/user/delrole', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('36', '0', '13', 'admin', '状态设置', '', 'admin/user/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('37', '0', '14', 'admin', '添加管理员', '', 'admin/user/adduser', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('38', '0', '14', 'admin', '修改管理员', '', 'admin/user/edituser', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('39', '0', '14', 'admin', '删除管理员', '', 'admin/user/deluser', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('40', '0', '14', 'admin', '状态设置', '', 'admin/user/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('41', '0', '14', 'admin', '个人信息设置', '', 'admin/user/info', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('42', '0', '18', 'admin', '安装插件', '', 'admin/plugins/install', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('43', '0', '18', 'admin', '卸载插件', '', 'admin/plugins/uninstall', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('44', '0', '18', 'admin', '删除插件', '', 'admin/plugins/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('45', '0', '18', 'admin', '状态设置', '', 'admin/plugins/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('46', '0', '18', 'admin', '设计插件', '', 'admin/plugins/design', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('47', '0', '18', 'admin', '运行插件', '', 'admin/plugins/run', '', '_self', '6', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('48', '0', '18', 'admin', '更新插件', '', 'admin/plugins/update', '', '_self', '7', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('49', '0', '18', 'admin', '插件配置', '', 'admin/plugins/setting', '', '_self', '8', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('50', '0', '19', 'admin', '添加钩子', '', 'admin/hook/add', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('51', '0', '19', 'admin', '修改钩子', '', 'admin/hook/edit', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('52', '0', '19', 'admin', '删除钩子', '', 'admin/hook/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('53', '0', '19', 'admin', '状态设置', '', 'admin/hook/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('54', '0', '19', 'admin', '插件排序', '', 'admin/hook/sort', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('55', '0', '11', 'admin', '添加配置', '', 'admin/config/add', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('56', '0', '11', 'admin', '修改配置', '', 'admin/config/edit', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('57', '0', '11', 'admin', '删除配置', '', 'admin/config/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('58', '0', '11', 'admin', '状态设置', '', 'admin/config/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('59', '0', '11', 'admin', '排序设置', '', 'admin/config/sort', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('60', '0', '10', 'admin', '基础配置', '', 'admin/system/index', 'group=base', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('61', '0', '10', 'admin', '系统配置', '', 'admin/system/index', 'group=sys', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('62', '0', '10', 'admin', '上传配置', '', 'admin/system/index', 'group=upload', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('63', '0', '10', 'admin', '开发配置', '', 'admin/system/index', 'group=develop', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('64', '0', '17', 'admin', '设计模块', '', 'admin/module/design', '', '_self', '6', '1', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('65', '0', '17', 'admin', '安装模块', '', 'admin/module/install', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('66', '0', '17', 'admin', '卸载模块', '', 'admin/module/uninstall', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('67', '0', '17', 'admin', '状态设置', '', 'admin/module/status', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('68', '0', '17', 'admin', '设置默认模块', '', 'admin/module/setdefault', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('69', '0', '17', 'admin', '删除模块', '', 'admin/module/del', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('70', '0', '21', 'admin', '添加会员', '', 'admin/member/add', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('71', '0', '21', 'admin', '修改会员', '', 'admin/member/edit', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('72', '0', '21', 'admin', '删除会员', '', 'admin/member/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('73', '0', '21', 'admin', '状态设置', '', 'admin/member/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('74', '0', '21', 'admin', '[弹窗]会员选择', '', 'admin/member/pop', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('75', '0', '20', 'admin', '添加会员等级', '', 'admin/member/addlevel', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('76', '0', '20', 'admin', '修改会员等级', '', 'admin/member/editlevel', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('77', '0', '20', 'admin', '删除会员等级', '', 'admin/member/dellevel', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('78', '0', '16', 'admin', '附件上传', '', 'admin/annex/upload', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('79', '0', '16', 'admin', '删除附件', '', 'admin/annex/del', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('80', '0', '8', 'admin', '在线升级', 'aicon ai-iconfontshengji', 'admin/upgrade/index', '', '_self', '4', '0', '1', '1', '1', '1491352728');
INSERT INTO `hisi_admin_menu` VALUES ('81', '0', '80', 'admin', '获取升级列表', '', 'admin/upgrade/lists', '', '_self', '0', '0', '1', '1', '1', '1491353504');
INSERT INTO `hisi_admin_menu` VALUES ('82', '0', '80', 'admin', '安装升级包', '', 'admin/upgrade/install', '', '_self', '0', '0', '1', '1', '1', '1491353568');
INSERT INTO `hisi_admin_menu` VALUES ('83', '0', '80', 'admin', '下载升级包', '', 'admin/upgrade/download', '', '_self', '0', '0', '1', '1', '1', '1491395830');
INSERT INTO `hisi_admin_menu` VALUES ('84', '0', '6', 'admin', '数据库管理', 'aicon ai-shujukuguanli', 'admin/database/index', '', '_self', '8', '0', '1', '1', '1', '1491461136');
INSERT INTO `hisi_admin_menu` VALUES ('85', '0', '84', 'admin', '备份数据库', '', 'admin/database/export', '', '_self', '0', '0', '1', '1', '1', '1491461250');
INSERT INTO `hisi_admin_menu` VALUES ('86', '0', '84', 'admin', '恢复数据库', '', 'admin/database/import', '', '_self', '0', '0', '1', '1', '1', '1491461315');
INSERT INTO `hisi_admin_menu` VALUES ('87', '0', '84', 'admin', '优化数据库', '', 'admin/database/optimize', '', '_self', '0', '0', '1', '1', '1', '1491467000');
INSERT INTO `hisi_admin_menu` VALUES ('88', '0', '84', 'admin', '删除备份', '', 'admin/database/del', '', '_self', '0', '0', '1', '1', '1', '1491467058');
INSERT INTO `hisi_admin_menu` VALUES ('89', '0', '84', 'admin', '修复数据库', '', 'admin/database/repair', '', '_self', '0', '0', '1', '1', '1', '1491880879');
INSERT INTO `hisi_admin_menu` VALUES ('90', '0', '21', 'admin', '设置默认等级', '', 'admin/member/setdefault', '', '_self', '0', '0', '1', '1', '1', '1491966585');
INSERT INTO `hisi_admin_menu` VALUES ('91', '0', '10', 'admin', '数据库配置', '', 'admin/system/index', 'group=databases', '_self', '5', '0', '1', '0', '1', '1492072213');
INSERT INTO `hisi_admin_menu` VALUES ('92', '0', '17', 'admin', '模块打包', '', 'admin/module/package', '', '_self', '7', '0', '1', '1', '1', '1492134693');
INSERT INTO `hisi_admin_menu` VALUES ('93', '0', '18', 'admin', '插件打包', '', 'admin/plugins/package', '', '_self', '0', '0', '1', '1', '1', '1492134743');
INSERT INTO `hisi_admin_menu` VALUES ('94', '0', '17', 'admin', '主题管理', '', 'admin/module/theme', '', '_self', '8', '0', '1', '1', '1', '1492433470');
INSERT INTO `hisi_admin_menu` VALUES ('95', '0', '17', 'admin', '设置默认主题', '', 'admin/module/setdefaulttheme', '', '_self', '9', '0', '1', '1', '1', '1492433618');
INSERT INTO `hisi_admin_menu` VALUES ('96', '0', '17', 'admin', '删除主题', '', 'admin/module/deltheme', '', '_self', '10', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('97', '0', '6', 'admin', '语言包管理', '', 'admin/language/index', '', '_self', '11', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('98', '0', '97', 'admin', '添加语言包', '', 'admin/language/add', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('99', '0', '97', 'admin', '修改语言包', '', 'admin/language/edit', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('100', '0', '97', 'admin', '删除语言包', '', 'admin/language/del', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('101', '0', '97', 'admin', '排序设置', '', 'admin/language/sort', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('102', '0', '97', 'admin', '状态设置', '', 'admin/language/status', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('103', '0', '16', 'admin', '收藏夹图标上传', '', 'admin/annex/favicon', '', '_self', '3', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('104', '0', '17', 'admin', '导入模块', '', 'admin/module/import', '', '_self', '11', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('105', '0', '4', 'admin', '系统信息', 'aicon ai-icon01', 'admin/index/sysinfo', '', '_self', '100', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('106', '0', '4', 'admin', '布局切换', '', 'admin/user/iframe', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('107', '0', '15', 'admin', '删除日志', '', 'admin/log/del', 'table=admin_log', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('108', '0', '15', 'admin', '清空日志', '', 'admin/log/clear', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('109', '0', '17', 'admin', '编辑模块', '', 'admin/module/edit', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('110', '0', '17', 'admin', '模块图标上传', '', 'admin/module/icon', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('111', '0', '18', 'admin', '导入插件', '', 'admin/plugins/import', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('112', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('113', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('114', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('115', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('116', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('117', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('118', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('119', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('120', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('121', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('122', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('123', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('124', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('125', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('126', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('127', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('128', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('129', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('130', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('131', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('132', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('133', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('134', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('135', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('136', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('137', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('138', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('139', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('140', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('141', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('142', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('143', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('144', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('145', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('146', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('147', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('148', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('149', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('150', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('151', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('152', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('153', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('154', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('155', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('156', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('157', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('158', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('159', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('160', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('161', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('162', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('163', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('164', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('165', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('166', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('167', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('168', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('169', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('170', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('171', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('172', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('173', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('174', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('175', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('176', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('177', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('178', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('179', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('180', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('181', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('182', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('183', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('184', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('185', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('186', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('187', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('188', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('189', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('190', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('191', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('192', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('193', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('194', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('195', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('196', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('197', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('198', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('199', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('200', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('212', '0', '0', 'cofco', '数据分析', 'aicon ai-shezhi', 'cofco', '', '_self', '200', '0', '0', '1', '1', '1522326412');
INSERT INTO `hisi_admin_menu` VALUES ('213', '0', '212', 'cofco', '爬虫管理', 'aicon ai-chajianguanli', 'cofco/spider', '', '_self', '0', '0', '1', '1', '1', '1522326707');
INSERT INTO `hisi_admin_menu` VALUES ('214', '0', '213', 'cofco', '使用必读', 'aicon ai-error', 'cofco/spider/index', '', '_self', '0', '0', '1', '1', '1', '1522326764');
INSERT INTO `hisi_admin_menu` VALUES ('216', '0', '213', 'cofco', '爬虫列表', 'aicon ai-caidan', 'cofco/spider/spider_list', '', '_self', '10', '0', '1', '1', '1', '1522384075');
INSERT INTO `hisi_admin_menu` VALUES ('217', '0', '213', 'cofco', '关键词列表', 'aicon ai-icon-test', 'cofco/spider/keywords_list', '', '_self', '5', '0', '1', '1', '1', '1522384176');
INSERT INTO `hisi_admin_menu` VALUES ('219', '0', '212', 'cofco', '数据筛选', 'aicon ai-shujukuguanli', 'cofco/labeldata', '', '_self', '10', '0', '1', '1', '1', '1522386289');
INSERT INTO `hisi_admin_menu` VALUES ('220', '0', '219', 'cofco', '人工输入', 'aicon ai-huiyuandengji', 'cofco/labeldata', '', '_self', '10', '0', '1', '1', '1', '1522386401');
INSERT INTO `hisi_admin_menu` VALUES ('221', '0', '219', 'cofco', '辅助输入', 'aicon ai-huiyuanliebiao', 'cofco/labeldata', '', '_self', '20', '0', '1', '1', '1', '1522386430');
INSERT INTO `hisi_admin_menu` VALUES ('222', '0', '219', 'cofco', '待审列表', 'aicon ai-clear', 'cofco/labeldata', '', '_self', '30', '0', '1', '1', '1', '1522386467');
INSERT INTO `hisi_admin_menu` VALUES ('223', '0', '219', 'cofco', '标签列表', 'typcn typcn-beer', 'cofco/labeldata', '', '_self', '5', '0', '1', '1', '1', '1522386522');
INSERT INTO `hisi_admin_menu` VALUES ('224', '0', '219', 'cofco', '使用必读', 'aicon ai-error', 'cofco/labeldata/index', '', '_self', '0', '0', '1', '1', '1', '1522386631');
INSERT INTO `hisi_admin_menu` VALUES ('225', '0', '219', 'cofco', '标签分组', 'aicon ai-xitongrizhi-tiaoshi', 'cofco/labeldata', '', '_self', '2', '0', '1', '1', '1', '1522387090');
INSERT INTO `hisi_admin_menu` VALUES ('226', '0', '212', 'cofco', '数据分析', 'typcn typcn-flow-switch', 'cofco/dataanalyse', '', '_self', '20', '0', '1', '1', '1', '1522388011');
INSERT INTO `hisi_admin_menu` VALUES ('227', '0', '226', 'cofco', '使用必读', 'aicon ai-error', 'cofco/dataanalyse/index', '', '_self', '0', '0', '1', '1', '1', '1522388052');

-- -----------------------------
-- Table structure for `hisi_admin_menu_lang`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_menu_lang`;
CREATE TABLE `hisi_admin_menu_lang` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(120) NOT NULL DEFAULT '' COMMENT '标题',
  `lang` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '语言包',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=331 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hisi_admin_menu_lang`
-- -----------------------------
INSERT INTO `hisi_admin_menu_lang` VALUES ('132', '2', '系统', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('134', '4', '快捷菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('136', '6', '系统功能', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('137', '7', '会员管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('138', '8', '系统扩展', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('139', '9', '开发专用', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('140', '10', '系统设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('141', '11', '配置管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('142', '12', '系统菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('143', '13', '管理员角色', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('144', '14', '系统管理员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('145', '15', '系统日志', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('146', '16', '附件管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('147', '17', '模块管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('148', '18', '插件管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('149', '19', '钩子管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('150', '20', '会员等级', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('151', '21', '会员列表', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('152', '22', '[示例]列表模板', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('153', '23', '[示例]编辑模板', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('155', '25', '清空缓存', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('156', '26', '添加菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('157', '27', '修改菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('158', '28', '删除菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('159', '29', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('160', '30', '排序设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('161', '31', '添加快捷菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('162', '32', '导出菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('163', '33', '添加角色', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('164', '34', '修改角色', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('165', '35', '删除角色', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('166', '36', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('167', '37', '添加管理员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('168', '38', '修改管理员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('169', '39', '删除管理员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('170', '40', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('171', '41', '个人信息设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('172', '42', '安装插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('173', '43', '卸载插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('174', '44', '删除插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('175', '45', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('176', '46', '设计插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('177', '47', '运行插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('178', '48', '更新插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('179', '49', '插件配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('180', '50', '添加钩子', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('181', '51', '修改钩子', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('182', '52', '删除钩子', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('183', '53', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('184', '54', '插件排序', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('185', '55', '添加配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('186', '56', '修改配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('187', '57', '删除配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('188', '58', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('189', '59', '排序设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('190', '60', '基础配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('191', '61', '系统配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('192', '62', '上传配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('193', '63', '开发配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('194', '64', '设计模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('195', '65', '安装模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('196', '66', '卸载模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('197', '67', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('198', '68', '设置默认模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('199', '69', '删除模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('200', '70', '添加会员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('201', '71', '修改会员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('202', '72', '删除会员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('203', '73', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('204', '74', '[弹窗]会员选择', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('205', '75', '添加会员等级', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('206', '76', '修改会员等级', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('207', '77', '删除会员等级', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('208', '78', '附件上传', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('209', '79', '删除附件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('210', '80', '在线升级', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('211', '81', '获取升级列表', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('212', '82', '安装升级包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('213', '83', '下载升级包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('214', '84', '数据库管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('215', '85', '备份数据库', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('216', '86', '恢复数据库', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('217', '87', '优化数据库', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('218', '88', '删除备份', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('219', '89', '修复数据库', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('220', '90', '设置默认等级', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('221', '91', '数据库配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('222', '92', '模块打包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('223', '93', '插件打包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('224', '94', '主题管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('225', '95', '设置默认主题', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('226', '96', '删除主题', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('227', '97', '语言包管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('228', '98', '添加语言包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('229', '99', '修改语言包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('230', '100', '删除语言包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('231', '101', '排序设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('232', '102', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('233', '103', '收藏夹图标上传', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('234', '104', '导入模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('235', '105', '欢迎页面', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('236', '106', '布局切换', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('237', '107', '删除日志', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('238', '108', '清空日志', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('239', '109', '编辑模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('240', '110', '模块图标上传', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('241', '111', '导入插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('242', '112', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('243', '113', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('244', '114', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('245', '115', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('246', '116', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('247', '117', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('248', '118', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('249', '119', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('250', '120', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('251', '121', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('252', '122', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('253', '123', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('254', '124', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('255', '125', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('256', '126', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('257', '127', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('258', '128', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('259', '129', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('260', '130', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('261', '131', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('262', '132', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('263', '133', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('264', '134', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('265', '135', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('266', '136', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('267', '137', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('268', '138', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('269', '139', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('270', '140', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('271', '141', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('272', '142', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('273', '143', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('274', '144', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('275', '145', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('276', '146', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('277', '147', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('278', '148', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('279', '149', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('280', '150', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('281', '151', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('282', '152', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('283', '153', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('284', '154', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('285', '155', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('286', '156', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('287', '157', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('288', '158', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('289', '159', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('290', '160', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('291', '161', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('292', '162', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('293', '163', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('294', '164', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('295', '165', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('296', '166', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('297', '167', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('298', '168', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('299', '169', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('300', '170', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('301', '171', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('302', '172', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('303', '173', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('304', '174', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('305', '175', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('306', '176', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('307', '177', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('308', '178', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('309', '179', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('310', '180', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('311', '181', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('312', '182', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('313', '183', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('314', '184', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('315', '185', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('316', '186', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('317', '187', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('318', '188', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('319', '189', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('320', '190', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('321', '191', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('322', '192', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('323', '193', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('324', '194', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('325', '195', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('326', '196', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('327', '197', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('328', '198', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('329', '199', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('330', '200', '预留占位', '1');

-- -----------------------------
-- Table structure for `hisi_admin_module`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_module`;
CREATE TABLE `hisi_admin_module` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '系统模块',
  `name` varchar(50) NOT NULL COMMENT '模块名(英文)',
  `identifier` varchar(100) NOT NULL COMMENT '模块标识(模块名(字母).开发者标识.module)',
  `title` varchar(50) NOT NULL COMMENT '模块标题',
  `intro` varchar(255) NOT NULL COMMENT '模块简介',
  `author` varchar(100) NOT NULL COMMENT '作者',
  `icon` varchar(80) NOT NULL DEFAULT 'aicon ai-mokuaiguanli' COMMENT '图标',
  `version` varchar(20) NOT NULL COMMENT '版本号',
  `url` varchar(255) NOT NULL COMMENT '链接',
  `sort` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0未安装，1未启用，2已启用',
  `default` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '默认模块(只能有一个)',
  `config` text NOT NULL COMMENT '配置',
  `app_id` varchar(30) NOT NULL DEFAULT '0' COMMENT '应用市场ID(0本地)',
  `app_keys` varchar(200) DEFAULT '' COMMENT '应用秘钥',
  `theme` varchar(50) NOT NULL DEFAULT 'default' COMMENT '主题模板',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `identifier` (`identifier`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='[系统] 模块';

-- -----------------------------
-- Records of `hisi_admin_module`
-- -----------------------------
INSERT INTO `hisi_admin_module` VALUES ('1', '1', 'admin', 'admin.hisiphp.module', '系统管理模块', '系统核心模块，用于后台各项管理功能模块及功能拓展', 'HisiPHP官方出品', '', '1.0.0', 'http://www.hisiphp.com', '0', '2', '0', '', '0', '', 'default', '1489998096', '1489998096');
INSERT INTO `hisi_admin_module` VALUES ('2', '1', 'index', 'index.hisiphp.module', '系统默认模块', '仅供前端插件访问和应用市场推送安装，禁止在此模块下面开发任何东西。', 'HisiPHP官方出品', '', '1.0.0', 'http://www.hisiphp.com', '0', '2', '0', '', '0', '', 'default', '1489998096', '1489998096');
INSERT INTO `hisi_admin_module` VALUES ('3', '1', 'install', 'install.hisiphp.module', '系统安装模块', '系统安装模块，勿动。', 'HisiPHP官方出品', '', '1.0.0', 'http://www.hisiphp.com', '0', '2', '0', '', '0', '', 'default', '1489998096', '1489998096');
INSERT INTO `hisi_admin_module` VALUES ('6', '0', 'cofco', 'cofco.btbu.module', '数据分析', '该模块主要开发中粮的数据分析系统，包含爬虫管理、数据输入、数据筛选、结果分析等功能', 'btbu', '/static/app_icon/cofco.png', '1.0.0', '', '0', '1', '0', '', '0', '', 'default', '1522326403', '1522326403');

-- -----------------------------
-- Table structure for `hisi_admin_plugins`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_plugins`;
CREATE TABLE `hisi_admin_plugins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(32) NOT NULL COMMENT '插件名称(英文)',
  `title` varchar(32) NOT NULL COMMENT '插件标题',
  `icon` varchar(64) NOT NULL COMMENT '图标',
  `intro` text NOT NULL COMMENT '插件简介',
  `author` varchar(32) NOT NULL COMMENT '作者',
  `url` varchar(255) NOT NULL COMMENT '作者主页',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `identifier` varchar(64) NOT NULL DEFAULT '' COMMENT '插件唯一标识符',
  `config` text NOT NULL COMMENT '插件配置',
  `app_id` varchar(30) NOT NULL DEFAULT '0' COMMENT '应用市场ID(0本地)',
  `app_keys` varchar(200) DEFAULT '' COMMENT '应用秘钥',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 插件表';

-- -----------------------------
-- Records of `hisi_admin_plugins`
-- -----------------------------
INSERT INTO `hisi_admin_plugins` VALUES ('1', '0', 'hisiphp', '系统基础信息', '/plugins/hisiphp/hisiphp.png', '后台首页展示系统基础信息和开发团队信息', 'HisiPHP', 'http://www.hisiphp.com', '1.0.0', 'hisiphp.hisiphp.plugins', '', '0', '', '1509379331', '1509379331', '0', '2');

-- -----------------------------
-- Table structure for `hisi_admin_role`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_role`;
CREATE TABLE `hisi_admin_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '角色名称',
  `intro` varchar(200) NOT NULL COMMENT '角色简介',
  `auth` text NOT NULL COMMENT '角色权限',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='[系统] 管理角色';

-- -----------------------------
-- Records of `hisi_admin_role`
-- -----------------------------
INSERT INTO `hisi_admin_role` VALUES ('1', '超级管理员', '拥有系统最高权限', '0', '1489411760', '0', '1');
INSERT INTO `hisi_admin_role` VALUES ('2', '系统管理员', '拥有系统管理员权限', '[\"1\",\"4\",\"25\",\"24\",\"2\",\"6\",\"10\",\"60\",\"61\",\"62\",\"63\",\"91\",\"11\",\"55\",\"56\",\"57\",\"58\",\"59\",\"12\",\"26\",\"27\",\"28\",\"29\",\"30\",\"31\",\"32\",\"13\",\"33\",\"34\",\"35\",\"36\",\"14\",\"37\",\"38\",\"39\",\"40\",\"41\",\"16\",\"78\",\"79\",\"84\",\"85\",\"86\",\"87\",\"88\",\"89\",\"7\",\"20\",\"75\",\"76\",\"77\",\"21\",\"90\",\"70\",\"71\",\"72\",\"73\",\"74\",\"8\",\"17\",\"65\",\"66\",\"67\",\"68\",\"94\",\"95\",\"18\",\"42\",\"43\",\"45\",\"47\",\"48\",\"49\",\"19\",\"80\",\"81\",\"82\",\"83\",\"9\",\"22\",\"23\",\"3\",\"5\"]', '1489411760', '0', '1');
INSERT INTO `hisi_admin_role` VALUES ('3', '数据标注员', '标注数据', '{\"6\":\"2\",\"7\":\"6\",\"28\":\"13\",\"29\":\"33\",\"30\":\"34\",\"31\":\"35\",\"32\":\"36\",\"33\":\"14\",\"34\":\"37\",\"35\":\"38\",\"36\":\"39\",\"37\":\"40\",\"38\":\"41\",\"39\":\"15\",\"40\":\"107\",\"41\":\"108\",\"42\":\"16\",\"43\":\"78\",\"44\":\"79\",\"45\":\"103\",\"46\":\"84\",\"47\":\"85\",\"48\":\"86\",\"49\":\"87\",\"50\":\"88\",\"51\":\"89\",\"52\":\"97\",\"53\":\"98\",\"54\":\"99\",\"55\":\"100\",\"56\":\"101\",\"57\":\"102\"}', '1522151575', '1522151575', '1');

-- -----------------------------
-- Table structure for `hisi_admin_user`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_user`;
CREATE TABLE `hisi_admin_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '角色ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(64) NOT NULL,
  `nick` varchar(50) NOT NULL COMMENT '昵称',
  `mobile` varchar(11) NOT NULL,
  `email` varchar(50) NOT NULL COMMENT '邮箱',
  `auth` text NOT NULL COMMENT '权限',
  `iframe` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0默认，1框架',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `last_login_ip` varchar(128) NOT NULL COMMENT '最后登陆IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登陆时间',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='[系统] 管理用户';

-- -----------------------------
-- Records of `hisi_admin_user`
-- -----------------------------
INSERT INTO `hisi_admin_user` VALUES ('1', '1', 'admin', '$2y$10$lbBUV/DOKZfU2AgW6XyR2OG77zo8zLf9S3m/8jzUiNNpWST9MU5yu', '超级管理员', '', '', '', '0', '1', '0.0.0.0', '1522395642', '1522151228', '1522395642');
INSERT INTO `hisi_admin_user` VALUES ('2', '3', 'data', '$2y$10$Qcw..WwtjHXqsIwbB1R//uREPZKA9GJbNTVjHFpzx1Xcw62GWyBrO', 'label', '', '', '{\"0\":\"1\",\"1\":\"4\",\"2\":\"25\",\"3\":\"24\",\"4\":\"105\",\"5\":\"106\",\"6\":\"2\",\"7\":\"6\",\"28\":\"13\",\"29\":\"33\",\"30\":\"34\",\"31\":\"35\",\"32\":\"36\",\"33\":\"14\",\"34\":\"37\",\"35\":\"38\",\"36\":\"39\",\"37\":\"40\",\"38\":\"41\",\"39\":\"15\",\"40\":\"107\",\"41\":\"108\",\"42\":\"16\",\"43\":\"78\",\"44\":\"79\",\"45\":\"103\",\"46\":\"84\",\"47\":\"85\",\"48\":\"86\",\"49\":\"87\",\"50\":\"88\",\"51\":\"89\",\"52\":\"97\",\"53\":\"98\",\"54\":\"99\",\"55\":\"100\",\"56\":\"101\",\"57\":\"102\"}', '0', '1', '0.0.0.0', '1522151680', '1522151609', '1522151680');
